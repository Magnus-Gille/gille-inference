#!/usr/bin/env node
/**
 * m5 — secret-safe owner-agent client for the Gille Inference gateway.
 *
 * Credentials are resolved internally from macOS Keychain profile accounts. This command
 * deliberately has no key/token/environment/config/argv credential input.
 */
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { isAbsolute, join } from "node:path";
import {
  M5_ASK_TIMEOUT_MS_DEFAULT,
  M5_ASK_TIMEOUT_MS_MAX,
  M5_ASK_TIMEOUT_MS_MIN,
  M5_CLIENT_VERSION,
  M5ClientError,
  createKeychainCredentialStore,
  createM5Client,
  diagnoseProfile,
  provisionRemediation,
  redactText,
  validateProfileConfig,
} from "./m5-client.mjs";
import { provisionProfile } from "./m5-provision.mjs";
import { createMcpStdioBridge, runMcpStdioBridge } from "./m5-stdio-bridge.mjs";
import { getBuildStatus, loadBuildConfig, parseBuildArgs, runBuild } from "./m5-build.mjs";

const MAX_STDIN_BYTES = 3 * 1024 * 1024;

export function defaultConfigPath() {
  return join(homedir(), ".config", "m5", "config.json");
}

export function loadM5Config(path = defaultConfigPath()) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(path, "utf8"));
  } catch {
    throw new M5ClientError(
      "missing_config",
      "No valid m5 profile configuration is available.",
    );
  }
  if (
    !parsed ||
    typeof parsed !== "object" ||
    parsed.version !== 1 ||
    !parsed.profiles ||
    typeof parsed.profiles !== "object"
  ) {
    throw new M5ClientError(
      "invalid_config",
      "m5 config must use version 1 and contain a profiles object.",
    );
  }
  return parsed;
}

function parseGlobalArgs(argv) {
  let profile;
  let endpoint = "public";
  let privateRequested = false;
  let publicRequested = false;
  let routeFlagCount = 0;
  let publicGatewayUrl;
  let sshTarget;
  let authHelper;
  let timeoutMsRaw;
  let checkLatest = false;
  let probeInferenceModel;
  const positional = [];
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--profile") {
      const value = argv[index + 1];
      if (!value || value.startsWith("-")) {
        throw new M5ClientError("invalid_args", "--profile requires a profile name.");
      }
      profile = value;
      index += 1;
    } else if (arg === "--private") {
      endpoint = "private";
      privateRequested = true;
      routeFlagCount += 1;
    } else if (arg === "--public") {
      endpoint = "public";
      publicRequested = true;
      routeFlagCount += 1;
    } else if (arg === "--probe-inference") {
      if (probeInferenceModel !== undefined) {
        throw new M5ClientError("invalid_args", "--probe-inference may be specified only once.");
      }
      const value = argv[index + 1];
      if (!value || value.startsWith("-")) {
        throw new M5ClientError("invalid_args", "--probe-inference requires a model identifier.");
      }
      probeInferenceModel = value;
      index += 1;
    } else if (arg === "--public-gateway-url") {
      const value = argv[index + 1];
      if (!value || value.startsWith("-")) {
        throw new M5ClientError("invalid_args", "--public-gateway-url requires an HTTPS URL.");
      }
      publicGatewayUrl = value;
      index += 1;
    } else if (arg === "--m5-host") {
      const value = argv[index + 1];
      if (!value || value.startsWith("-")) {
        throw new M5ClientError("invalid_args", "--m5-host requires an SSH host or user@host value.");
      }
      sshTarget = value;
      index += 1;
    } else if (arg === "--auth-helper") {
      const value = argv[index + 1];
      if (!value || value.startsWith("-")) {
        throw new M5ClientError(
          "invalid_args",
          "--auth-helper requires an absolute path to m5-auth.",
        );
      }
      if (authHelper !== undefined) {
        throw new M5ClientError(
          "invalid_args",
          "--auth-helper may be specified only once.",
        );
      }
      authHelper = value;
      index += 1;
    } else if (arg === "--timeout-ms") {
      const value = argv[index + 1];
      if (timeoutMsRaw !== undefined) {
        throw new M5ClientError(
          "invalid_args",
          "--timeout-ms may be specified only once.",
        );
      }
      if (!value || value.startsWith("-")) {
        throw new M5ClientError(
          "invalid_args",
          "--timeout-ms requires an integer number of milliseconds.",
        );
      }
      timeoutMsRaw = value;
      index += 1;
    } else if (arg === "--check-latest") {
      if (checkLatest) {
        throw new M5ClientError("invalid_args", "--check-latest may be specified only once.");
      }
      checkLatest = true;
    } else if (arg === "--help" || arg === "-h") {
      positional.push("help");
    } else if (arg === "--version" || arg === "-v") {
      positional.push("version");
    } else {
      positional.push(arg);
    }
  }
  return {
    profile,
    endpoint,
    privateRequested,
    publicRequested,
    routeFlagCount,
    positional,
    publicGatewayUrl,
    sshTarget,
    authHelper,
    timeoutMsRaw,
    checkLatest,
    probeInferenceModel,
  };
}

/**
 * Direct-ask request timeout (#154): a strict integer in M5_ASK_TIMEOUT_MS_MIN..
 * M5_ASK_TIMEOUT_MS_MAX. Fractional, non-numeric, and out-of-range values are rejected
 * before config or credential access. The value travels only into createM5Client — never
 * into MCP arguments, profile config, environment, logs, or telemetry.
 */
function parseAskTimeoutMs(raw) {
  if (!/^\d+$/.test(raw)) {
    throw new M5ClientError(
      "invalid_args",
      `--timeout-ms must be an integer number of milliseconds from ${M5_ASK_TIMEOUT_MS_MIN} to ${M5_ASK_TIMEOUT_MS_MAX}.`,
    );
  }
  const parsed = Number(raw);
  if (
    !Number.isSafeInteger(parsed) ||
    parsed < M5_ASK_TIMEOUT_MS_MIN ||
    parsed > M5_ASK_TIMEOUT_MS_MAX
  ) {
    throw new M5ClientError(
      "invalid_args",
      `--timeout-ms must be an integer number of milliseconds from ${M5_ASK_TIMEOUT_MS_MIN} to ${M5_ASK_TIMEOUT_MS_MAX}.`,
    );
  }
  return parsed;
}

async function readBoundedInput(input) {
  input.setEncoding?.("utf8");
  let text = "";
  for await (const chunk of input) {
    text += String(chunk);
    if (Buffer.byteLength(text, "utf8") > MAX_STDIN_BYTES) {
      throw new M5ClientError(
        "input_too_large",
        "Structured JSON input exceeds the 3 MiB client limit.",
      );
    }
  }
  if (text.trim() === "") {
    throw new M5ClientError("invalid_input", "Structured JSON input is required on stdin.");
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new M5ClientError("invalid_input", "stdin must contain one valid JSON value.");
  }
}

function writeJson(stream, value) {
  stream.write(`${JSON.stringify(value)}\n`);
}

function shellQuote(value) {
  return `'${String(value).replaceAll("'", `'"'"'`)}'`;
}

function writeDeployEnv(stream, publicGatewayUrl, authHelper) {
  const publicHttpUrl = new URL(publicGatewayUrl);
  publicHttpUrl.protocol = "http:";
  const authCommand = shellQuote(authHelper);
  stream.write([
    "unset M5_API_KEY HOMESERVER_OWNER_KEY \\",
    "  DEPLOY_HEALTH_TAILNET_URL DEPLOY_CAPABILITY_URL \\",
    "  DEPLOY_PUBLIC_HTTP_URL DEPLOY_PUBLIC_HTTPS_URL &&",
    `eval "$(${authCommand} --env --tailnet)" &&`,
    'test -n "${M5_API_KEY:-}" &&',
    'export HOMESERVER_OWNER_KEY="$M5_API_KEY" &&',
    "unset M5_API_KEY &&",
    'export DEPLOY_HEALTH_TAILNET_URL="${M5_GATEWAY_URL%/}/healthz" &&',
    'export DEPLOY_CAPABILITY_URL="${M5_GATEWAY_URL%/}/v1/capabilities/learning-task" &&',
    `export DEPLOY_PUBLIC_HTTP_URL=${shellQuote(publicHttpUrl.origin)} &&`,
    `export DEPLOY_PUBLIC_HTTPS_URL=${shellQuote(publicGatewayUrl)}`,
    "",
  ].join("\n"));
}

function help() {
  return {
    name: "m5",
    version: M5_CLIENT_VERSION,
    usage: [
      "m5 build status",
      "m5 build [--pull relative/file] [--toolchain version] -- command args",
      "m5 --profile <claude|codex> doctor [--check-latest]",
      "m5 --profile <claude|codex> [--public|--private] doctor --probe-inference <model>",
      "eval \"$(m5 --profile <name> deploy-env --auth-helper <absolute-path>)\"",
      "m5 --profile <claude|codex> [--public|--private] mcp",
      "m5 --profile <claude|codex> [--public|--private] models",
      "printf '%s' '<json>' | m5 --profile <claude|codex> [--timeout-ms <1000-600000>] ask",
      "printf '%s' '<content-free-json>' | m5 --profile <claude|codex> adoption report",
      "printf '%s' '{\"feedback_handle\":\"<uuid>\",\"usefulness\":\"pass\"}' | m5 --profile <claude|codex> feedback submit",
      "printf '%s' '<json>' | m5 --profile <claude|codex> code run",
      "m5 --profile <claude|codex> code status <work_id>",
      "m5 --profile <claude|codex> code result <work_id>",
      "m5 --profile <name> --public-gateway-url <https-url> --m5-host <user@host> provision",
    ],
    credential_source: "macOS Keychain profile account (internal only)",
    security_boundary:
      "The gateway sandbox and diff-only server result are authoritative; CLI defaults are not enforcement.",
  };
}

function selectedProfile(config, profile) {
  if (!profile) {
    throw new M5ClientError(
      "profile_required",
      "--profile is required so Claude and Codex never share a credential implicitly.",
    );
  }
  const raw = config.profiles[profile];
  if (!raw) {
    throw new M5ClientError(
      "unknown_profile",
      "The selected profile is not present in m5 config.",
      { remediation: provisionRemediation(profile) },
    );
  }
  return validateProfileConfig(raw);
}

export async function main(
  argv,
  {
    input = process.stdin,
    output = process.stdout,
    error = process.stderr,
    configLoader = loadM5Config,
    credentialStore = createKeychainCredentialStore(),
    fetch: fetchImpl = globalThis.fetch,
    bridgeRunner = runMcpStdioBridge,
    provisioner = provisionProfile,
    buildRunner = runBuild,
    buildStatusRunner = getBuildStatus,
  } = {},
) {
  let selectedProfileName;
  try {
    if (argv[0] === "build") {
      if (argv[1] === "status") {
        if (argv.length !== 2) throw new M5ClientError("invalid_args", "m5 build status accepts no arguments.");
        writeJson(output, await buildStatusRunner());
        return 0;
      }
      const parsed = parseBuildArgs(argv.slice(1));
      const result = await buildRunner({ ...parsed, stdout: output, stderr: error });
      return result.exit_code;
    }
    const {
      profile,
      endpoint,
      privateRequested,
      publicRequested,
      routeFlagCount,
      positional,
      publicGatewayUrl,
      sshTarget,
      authHelper,
      timeoutMsRaw,
      checkLatest,
      probeInferenceModel,
    } = parseGlobalArgs(argv);
    selectedProfileName = profile;
    const command = positional[0];
    // Scope before value: the flag is meaningless outside a direct ask, and both
    // rejections must land before config loading, credential lookup, or any I/O.
    if (timeoutMsRaw !== undefined && command !== "ask") {
      throw new M5ClientError(
        "invalid_args",
        "--timeout-ms is only valid with ask.",
      );
    }
    if (checkLatest && command !== "doctor") {
      throw new M5ClientError("invalid_args", "--check-latest is only valid with doctor.");
    }
    let inferenceProbe;
    if (probeInferenceModel !== undefined) {
      if (command !== "doctor") {
        throw new M5ClientError("invalid_args", "--probe-inference is only valid with doctor.");
      }
      if (!/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/.test(probeInferenceModel)) {
        throw new M5ClientError("invalid_args", "--probe-inference requires a valid model identifier.");
      }
      if (routeFlagCount !== 1 || publicRequested === privateRequested) {
        throw new M5ClientError("invalid_args", "--probe-inference requires exactly one of --public or --private.");
      }
      inferenceProbe = {
        route: privateRequested ? "private" : "public",
        model: probeInferenceModel,
      };
    }
    const askTimeoutMs =
      timeoutMsRaw === undefined ? M5_ASK_TIMEOUT_MS_DEFAULT : parseAskTimeoutMs(timeoutMsRaw);
    if (authHelper !== undefined && command !== "deploy-env") {
      throw new M5ClientError(
        "invalid_args",
        "--auth-helper is only valid with deploy-env.",
      );
    }
    if (command === "deploy-env") {
      if (positional.length !== 1) {
        throw new M5ClientError(
          "invalid_args",
          "deploy-env does not accept positional arguments.",
        );
      }
      if (authHelper === undefined) {
        throw new M5ClientError(
          "invalid_args",
          "--auth-helper is required with deploy-env.",
        );
      }
      if (!isAbsolute(authHelper)) {
        throw new M5ClientError(
          "invalid_args",
          "--auth-helper requires an absolute path to m5-auth.",
        );
      }
    }
    if (!command || command === "help") {
      writeJson(output, help());
      return 0;
    }
    if (command === "version") {
      writeJson(output, { name: "m5", version: M5_CLIENT_VERSION });
      return 0;
    }

    if (command === "provision") {
      if (!profile) {
        throw new M5ClientError("profile_required", "--profile is required for provisioning.");
      }
      const provisioned = await provisioner({
        profile,
        publicGatewayUrl,
        sshTarget,
        configPath: defaultConfigPath(),
      });
      const result = await diagnoseProfile({
        profile,
        profileConfig: provisioned.profileConfig,
        credentialStore,
        fetch: fetchImpl,
      });
      writeJson(output, result);
      return result.status === "mcp_reachable" ? 0 : 1;
    }
    if (publicGatewayUrl !== undefined || sshTarget !== undefined) {
      throw new M5ClientError("invalid_args", "--public-gateway-url and --m5-host are only valid with provision.");
    }

    const config = configLoader();
    const profileConfig = selectedProfile(config, profile);
    if (command === "deploy-env") {
      if (privateRequested) {
        throw new M5ClientError(
          "invalid_args",
          "--private is not valid with deploy-env; tailnet URLs come from m5-auth.",
        );
      }
      writeDeployEnv(output, profileConfig.publicGatewayUrl, authHelper);
      return 0;
    }
    if (command === "doctor") {
      const result = await diagnoseProfile({
        profile,
        profileConfig,
        credentialStore,
        fetch: fetchImpl,
        checkLatest,
        inferenceProbe,
      });
      writeJson(output, result);
      return result.status === "mcp_reachable" ? 0 : 1;
    }

    const gatewayUrl =
      endpoint === "private"
        ? profileConfig.privateGatewayUrl
        : profileConfig.publicGatewayUrl;
    if (!gatewayUrl) {
      throw new M5ClientError(
        "endpoint_not_configured",
        "The selected profile does not configure that gateway path.",
        {
          failureLayer: endpoint === "private" ? "private_route_unconfigured" : "public_route_unconfigured",
          retryable: false,
          remediation: `Configure the ${endpoint} gateway path for the profile, then verify it: m5 --profile ${/^[a-z][a-z0-9_-]{0,31}$/i.test(profile ?? "") ? profile : "selected"} doctor. Never point a profile at a loopback address as a substitute for a configured route.`,
        },
      );
    }
    const client = await createM5Client({
      gatewayUrl,
      endpoint,
      profile,
      credentialStore,
      fetch: fetchImpl,
      timeoutMs: askTimeoutMs,
    });

    if (command === "mcp") {
      let buildConfig;
      try { buildConfig = await loadBuildConfig(); } catch { /* Build is omitted unless locally configured. */ }
      const bridge = createMcpStdioBridge({ client, profile, buildConfig });
      await bridgeRunner({ bridge, input, output });
      return 0;
    }
    if (command === "models") {
      writeJson(output, await client.models());
      return 0;
    }
    if (command === "ask") {
      writeJson(output, await client.ask(await readBoundedInput(input)));
      return 0;
    }
    if (command === "adoption") {
      if (positional[1] !== "report") {
        throw new M5ClientError("invalid_args", "adoption requires: report.");
      }
      writeJson(output, await client.reportAdoption(await readBoundedInput(input)));
      return 0;
    }
    if (command === "feedback") {
      if (positional[1] !== "submit" || positional.length !== 2) {
        throw new M5ClientError("invalid_args", "feedback requires: submit.");
      }
      writeJson(output, await client.recordExecutionFeedback(await readBoundedInput(input)));
      return 0;
    }
    if (command === "code") {
      const operation = positional[1];
      if (operation === "run") {
        writeJson(output, await client.codeRun(await readBoundedInput(input)));
        return 0;
      }
      if (operation === "status") {
        writeJson(output, await client.codeStatus(positional[2]));
        return 0;
      }
      if (operation === "result") {
        writeJson(output, await client.codeResult(positional[2]));
        return 0;
      }
      throw new M5ClientError(
        "invalid_args",
        "code requires one of: run, status, result.",
      );
    }
    throw new M5ClientError("invalid_args", "Unknown m5 command.");
  } catch (caught) {
    const safe =
      caught instanceof M5ClientError
        ? caught
        : new M5ClientError(
            "client_error",
            redactText(caught instanceof Error ? caught.message : "m5 failed."),
          );
    writeJson(error, safe.toJSON(selectedProfileName));
    return argv[0] === "build" ? 125 : 1;
  }
}

const isMain =
  typeof process !== "undefined" &&
  process.argv[1] != null &&
  (process.argv[1].endsWith("/m5.mjs") || process.argv[1].endsWith("/m5"));

if (isMain) {
  process.exitCode = await main(process.argv.slice(2));
}
